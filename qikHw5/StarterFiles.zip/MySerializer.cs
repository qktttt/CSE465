using System;
using System.Reflection;

namespace Serializer {
	public class MySerializer {
		public static string Serialize(Object obj) {
			// stub
			// TODO: enter your code here
			return "hello world";
		}
		public static T Deserialize<T>(string str) {
			// stub
			// TODO: enter your code here
			Type type = typeof(T);
			ConstructorInfo ctor = type.GetConstructor(new Type[] { });
			T obj = (T)ctor.Invoke(new Object[] { });
			return obj;
		}
	}
	public class Point {
		public int x, y;
		public Point() {
			x = y = 0;
		}
		public Point(int X, int Y) {
			x = X;
			y = Y;
		}
	}
	
    public class Student {
		public String name;
		public double gpa;
		public bool is_undergrad;
		
		public Student()
		{
			name = "John Doe";
			gpa = 4.0;
			is_undergrad = true;
		}
		public Student(String n, double GPA, bool b)
		{
			name = n;
			gpa = GPA;
			is_undergrad = b;
		}
		public override string ToString()
		{
			return String.Format("{0} {1} {2}", name, gpa, is_undergrad);
		}
	}
	
	public class Test {
		public static void Main(String [] args) {	
			Point p1 = new Point(2, 3);
			String str1 = MySerializer.Serialize(p1);
			Console.WriteLine(str1);
			Point newPt = MySerializer.Deserialize<Point>(str1);
			Console.WriteLine(newPt);
			
			Student s1 = new Student("Test Student", 3.5, false);
			String str2 = MySerializer.Serialize(s1);
			Console.WriteLine(str2);
			Student newSt = MySerializer.Deserialize<Student>(str2);
			Console.WriteLine(newSt);
		}
	}
}

